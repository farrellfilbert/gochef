<?php
require_once 'db_connect.php';

header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    $user_id = $_GET['user_id'] ?? null;
    $kitchen_id = $_GET['kitchen_id'] ?? null;
    
    if (!$user_id && !$kitchen_id) {
        echo json_encode(['success' => false, 'error' => 'user_id or kitchen_id is required', 'data' => []]);
        exit();
    }
    
    $orders = [];
    
    if ($kitchen_id) {
        $stmt = $pdo->prepare("
            SELECT o.*, u.name as customer_name, u.phone as customer_phone, u.avatar as customer_avatar, k.user_id as kitchen_user_id
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            LEFT JOIN kitchens k ON o.kitchen_id = k.id
            WHERE o.kitchen_id = ? 
            ORDER BY o.id DESC
        ");
        $stmt->execute([$kitchen_id]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Check if user owns a kitchen
        $kStmt = $pdo->prepare("SELECT id FROM kitchens WHERE user_id = ? LIMIT 1");
        $kStmt->execute([$user_id]);
        $kitchen = $kStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($kitchen) {
            $chefKitchenId = $kitchen['id'];
            $stmt = $pdo->prepare("
                SELECT o.*, u.name as customer_name, u.phone as customer_phone, u.avatar as customer_avatar, k.user_id as kitchen_user_id
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.id 
                LEFT JOIN kitchens k ON o.kitchen_id = k.id
                WHERE o.kitchen_id = ? OR o.user_id = ?
                ORDER BY o.id DESC
            ");
            $stmt->execute([$chefKitchenId, $user_id]);
        } else {
            $stmt = $pdo->prepare("
                SELECT o.*, u.name as customer_name, u.phone as customer_phone, u.avatar as customer_avatar, k.user_id as kitchen_user_id
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.id 
                LEFT JOIN kitchens k ON o.kitchen_id = k.id
                WHERE o.user_id = ? 
                ORDER BY o.id DESC
            ");
            $stmt->execute([$user_id]);
        }
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    $response = [];
    foreach ($orders as $order) {
        $itemStmt = $pdo->prepare("SELECT oi.name, oi.options, oi.quantity, oi.price, 
            (SELECT image FROM menu_items mi WHERE mi.name = oi.name AND mi.kitchen_id = ? LIMIT 1) as image
            FROM order_items oi WHERE oi.order_id = ?");
        $itemStmt->execute([$order['kitchen_id'], $order['id']]);
        $items = $itemStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $response[] = [
            'id' => $order['id'],
            'user_id' => $order['user_id'],
            'customer_name' => $order['customer_name'] ?? 'Guest Customer',
            'customer_phone' => $order['customer_phone'] ?? '',
            'customer_avatar' => $order['customer_avatar'] ?? '',
            'kitchen_id' => $order['kitchen_id'],
            'kitchen_name' => $order['kitchen_name'],
            'date' => $order['order_date'],
            'order_type' => $order['order_type'] ?? 'delivery',
            'dine_in_date' => $order['dine_in_date'],
            'dine_in_time' => $order['dine_in_time'],
            'discount_amount' => (float)($order['discount_amount'] ?? 0),
            'promo_code' => $order['promo_code'],
            'status' => $order['status'],
            'total_amount' => (float)$order['total_amount'],
            'items_count' => (int)$order['items_count'],
            'avatar' => $order['avatar'],
            'delivery_address' => $order['delivery_address'] ?? '',
            'notes' => $order['notes'] ?? '',
            'items' => $items
        ];
    }
    
    echo json_encode([
        'success' => true,
        'data' => $response
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage(), 'data' => []]);
}
?>

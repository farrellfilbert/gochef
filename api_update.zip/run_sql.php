<?php
require_once 'db_connect.php';
$stmt = $pdo->query("SELECT id, name, user_id FROM kitchens");
$kitchens = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($kitchens);
?>
